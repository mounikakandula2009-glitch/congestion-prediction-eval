"""
=====================================================================================
 DeepRoute-C  —  ONE-FILE version for Google Colab
=====================================================================================
 HOW TO USE (read this, it's short):

   1) Put this whole file in ONE Colab cell (or upload it and run  !python deeproute_c_colab.py).
   2) Look at the CONFIG block right below. Leave MODE = "demo" the first time.
   3) Run it. It will create fake data, train for 2 epochs, and finish. This PROVES the
      code works on your machine. The NRMSE/SSIM it prints are MEANINGLESS (random data) —
      they are NOT results, just a plumbing test.
   4) When you have really downloaded CircuitNet (see the REAL DATA section at the bottom),
      set MODE = "real", set REAL_FEATURE_DIR / REAL_LABEL_DIR to the folders that
      CircuitNet's generate_training_set.py produced, and run again.

 You do not need to understand the internals. Edit CONFIG, run. That's it.
=====================================================================================
"""

import os, glob, shutil, random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# ============================= CONFIG (edit these) =============================
MODE   = "demo"     # "demo" = run now with fake data (no download).
                    # "real" = use your downloaded + preprocessed CircuitNet.

ROOT   = "./circuitnet_congestion"   # working folder; train/ and val/ are made here.

# Only used when MODE == "real":  the two folders generate_training_set.py created.
REAL_FEATURE_DIR = "/content/cn_congestion/feature"
REAL_LABEL_DIR   = "/content/cn_congestion/label"
VAL_FRACTION     = 0.2               # 20% of real samples held out for validation.

# Training settings
EPOCHS    = 2 if MODE == "demo" else 50
BATCH     = 4
LR        = 2e-4
IN_CH     = 3                         # CircuitNet congestion = 3 channels (macro, RUDY, RUDY_pin)
BASE      = 32
USE_GRAPH = False                    # leave False until GraphBranch is wired (see notes)
LAM, TAU  = 1.0, 0.6                 # hotspot-loss weight and threshold
DEVICE    = "cuda" if torch.cuda.is_available() else "cpu"
SAVE_PATH = "deeproute_c_best.pt"
# ==============================================================================


# ============================== DATA PREPARATION ==============================
def make_demo_data(root, n_train=20, n_val=5):
    print(">>> DEMO MODE: writing FAKE random data. Printed metrics will be meaningless.")
    for split, n in [("train", n_train), ("val", n_val)]:
        for sub in ("feature", "label"):
            os.makedirs(f"{root}/{split}/{sub}", exist_ok=True)
        for i in range(n):
            name = f"sample_{i:03d}.npy"
            np.save(f"{root}/{split}/feature/{name}", np.random.rand(IN_CH, 256, 256).astype("float32"))
            np.save(f"{root}/{split}/label/{name}",   np.random.rand(1, 256, 256).astype("float32"))
    print(f">>> wrote {n_train} train / {n_val} val fake samples to {root}")


def arrange_real_data(root, feature_dir, label_dir, val_fraction=0.2):
    """Take generate_training_set.py output (feature_dir + label_dir of .npy)
       and split it into root/train and root/val."""
    feats = sorted(glob.glob(os.path.join(feature_dir, "*.npy")))
    if not feats:
        raise FileNotFoundError(
            f"No .npy in {feature_dir}. Did you run generate_training_set.py --task congestion? "
            f"(see the REAL DATA section at the bottom of this file)")
    random.seed(0); random.shuffle(feats)
    n_val = max(1, int(len(feats) * val_fraction))
    splits = {"val": feats[:n_val], "train": feats[n_val:]}
    for split, files in splits.items():
        for sub in ("feature", "label"):
            os.makedirs(f"{root}/{split}/{sub}", exist_ok=True)
        for fp in files:
            name = os.path.basename(fp)
            lp = os.path.join(label_dir, name)
            if not os.path.exists(lp):
                continue  # skip samples without a matching label
            shutil.copy(fp, f"{root}/{split}/feature/{name}")
            shutil.copy(lp, f"{root}/{split}/label/{name}")
    n_tr = len(glob.glob(f"{root}/train/feature/*.npy"))
    n_va = len(glob.glob(f"{root}/val/feature/*.npy"))
    print(f">>> REAL MODE: arranged {n_tr} train / {n_va} val samples into {root}")


# ============================== DATASET ==============================
class CircuitNetCongestion(Dataset):
    def __init__(self, root, split, in_channels=3):
        self.fdir = os.path.join(root, split, "feature")
        self.ldir = os.path.join(root, split, "label")
        self.files = sorted(glob.glob(os.path.join(self.fdir, "*.npy")))
        if not self.files:
            raise FileNotFoundError(f"No .npy features in {self.fdir}")
        self.in_channels = in_channels

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        fp = self.files[i]
        name = os.path.basename(fp)
        x = np.load(fp).astype("float32")
        y = np.load(os.path.join(self.ldir, name)).astype("float32")
        if x.ndim == 2: x = x[None]
        if y.ndim == 2: y = y[None]
        if x.shape[0] != self.in_channels and x.shape[-1] == self.in_channels:
            x = np.transpose(x, (2, 0, 1))
        for c in range(x.shape[0]):
            ch = x[c]; rng = ch.max() - ch.min()
            x[c] = (ch - ch.min()) / (rng + 1e-8)
        y = y / (y.max() + 1e-8)
        return torch.from_numpy(x), torch.from_numpy(y)


# ============================== MODEL ==============================
def conv_block(cin, cout):
    return nn.Sequential(
        nn.Conv2d(cin, cout, 3, padding=1), nn.BatchNorm2d(cout), nn.ReLU(inplace=True),
        nn.Conv2d(cout, cout, 3, padding=1), nn.BatchNorm2d(cout), nn.ReLU(inplace=True))


class Inception(nn.Module):
    def __init__(self, c):
        super().__init__()
        q = c // 4
        self.b1 = nn.Conv2d(c, q, 1)
        self.b2 = nn.Conv2d(c, q, 3, padding=1)
        self.b3 = nn.Conv2d(c, q, 5, padding=2)
        self.b4 = nn.Sequential(nn.MaxPool2d(3, 1, 1), nn.Conv2d(c, q, 1))
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.act(torch.cat([self.b1(x), self.b2(x), self.b3(x), self.b4(x)], 1))


class CrossAttentionFusion(nn.Module):
    """Layout=queries, graph=keys/values. Graph None -> self-attention (image-only)."""
    def __init__(self, c, heads=4):
        super().__init__()
        assert c % heads == 0
        self.h, self.dh = heads, c // heads
        self.q = nn.Conv2d(c, c, 1); self.k = nn.Conv2d(c, c, 1); self.v = nn.Conv2d(c, c, 1)
        self.proj = nn.Conv2d(c, c, 1); self.norm = nn.GroupNorm(1, c)
    def forward(self, f_img, f_grf=None):
        if f_grf is None: f_grf = f_img
        B, C, H, W = f_img.shape; N = H * W
        q = self.q(f_img).reshape(B, self.h, self.dh, N)
        k = self.k(f_grf).reshape(B, self.h, self.dh, N)
        v = self.v(f_grf).reshape(B, self.h, self.dh, N)
        attn = torch.softmax(torch.einsum('bhdn,bhdm->bhnm', q, k) / (self.dh ** 0.5), dim=-1)
        out = torch.einsum('bhnm,bhdm->bhdn', attn, v).reshape(B, C, H, W)
        return f_img + self.proj(self.norm(out))


class GraphBranch(nn.Module):
    """NOVEL PART — wire to CircuitNet graph_features later. Returns None until then."""
    def __init__(self, c): super().__init__()
    def forward(self, *a, **k): return None


class DeepRouteC(nn.Module):
    def __init__(self, in_ch=3, base=32, heads=4, use_graph=False):
        super().__init__()
        self.use_graph = use_graph
        self.pool = nn.MaxPool2d(2)
        self.e1 = conv_block(in_ch, base)
        self.e2 = conv_block(base, base * 2)
        self.e3 = conv_block(base * 2, base * 4)
        self.e4 = conv_block(base * 4, base * 8)
        self.bott = conv_block(base * 8, base * 16)
        self.incept = Inception(base * 16)
        self.fuse = CrossAttentionFusion(base * 16, heads)
        self.graph = GraphBranch(base * 16) if use_graph else None
        self.up4 = nn.ConvTranspose2d(base * 16, base * 8, 2, 2); self.d4 = conv_block(base * 16, base * 8)
        self.up3 = nn.ConvTranspose2d(base * 8, base * 4, 2, 2);  self.d3 = conv_block(base * 8, base * 4)
        self.up2 = nn.ConvTranspose2d(base * 4, base * 2, 2, 2);  self.d2 = conv_block(base * 4, base * 2)
        self.up1 = nn.ConvTranspose2d(base * 2, base, 2, 2);      self.d1 = conv_block(base * 2, base)
        self.out = nn.Conv2d(base, 1, 1)
    def forward(self, x, graph_batch=None):
        H0, W0 = x.shape[-2], x.shape[-1]
        # U-Net downsamples by 16; pad odd sizes (e.g. 309) up to a multiple of
        # 16, then crop the output back so all shapes line up.
        ph = (16 - H0 % 16) % 16
        pw = (16 - W0 % 16) % 16
        if ph or pw:
            x = F.pad(x, (0, pw, 0, ph), mode="reflect")
        c1 = self.e1(x)
        c2 = self.e2(self.pool(c1))
        c3 = self.e3(self.pool(c2))
        c4 = self.e4(self.pool(c3))
        b = self.incept(self.bott(self.pool(c4)))
        f_grf = self.graph(graph_batch) if (self.use_graph and self.graph) else None
        b = self.fuse(b, f_grf)
        u4 = self.d4(torch.cat([self.up4(b), c4], 1))
        u3 = self.d3(torch.cat([self.up3(u4), c3], 1))
        u2 = self.d2(torch.cat([self.up2(u3), c2], 1))
        u1 = self.d1(torch.cat([self.up1(u2), c1], 1))
        out = torch.sigmoid(self.out(u1))
        return out[..., :H0, :W0]


# ============================== LOSS & METRICS ==============================
class HotspotLoss(nn.Module):
    def __init__(self, lam=1.0, tau=0.6, gamma=2.0):
        super().__init__(); self.lam, self.tau, self.gamma = lam, tau, gamma
    def forward(self, pred, target):
        base = F.mse_loss(pred, target)
        mask = (target >= self.tau).float()
        w = target.clamp(0, 1) ** self.gamma
        hot = ((pred - target) ** 2 * w * mask).sum() / (mask.sum() + 1e-8)
        return base + self.lam * hot


def nrmse_np(p, t):
    return np.sqrt(np.mean((p - t) ** 2)) / (t.max() - t.min() + 1e-8)


@torch.no_grad()
def evaluate(model, loader):
    try:
        from skimage.metrics import structural_similarity as ssim_fn
    except ImportError:
        ssim_fn = None
    model.eval(); nrmses, ssims = [], []
    for x, y in loader:
        x = x.to(DEVICE)
        p = model(x).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]):
            nrmses.append(nrmse_np(p[b, 0], t[b, 0]))
            if ssim_fn is not None:
                ssims.append(ssim_fn(p[b, 0], t[b, 0], data_range=1.0))
    out = {"NRMSE": float(np.mean(nrmses))}
    if ssims: out["SSIM"] = float(np.mean(ssims))
    return out


# ============================== TRAIN ==============================
def run():
    # 1) prepare data
    if MODE == "demo":
        if os.path.exists(ROOT): shutil.rmtree(ROOT)
        make_demo_data(ROOT)
    elif MODE == "real":
        if os.path.exists(ROOT): shutil.rmtree(ROOT)
        arrange_real_data(ROOT, REAL_FEATURE_DIR, REAL_LABEL_DIR, VAL_FRACTION)
    else:
        raise ValueError("MODE must be 'demo' or 'real'")

    # 2) build model
    model = DeepRouteC(in_ch=IN_CH, base=BASE, use_graph=USE_GRAPH).to(DEVICE)
    print(f"DeepRouteC params: {sum(p.numel() for p in model.parameters())/1e6:.2f}M | device={DEVICE}")

    tr = DataLoader(CircuitNetCongestion(ROOT, "train", IN_CH), batch_size=BATCH, shuffle=True)
    va = DataLoader(CircuitNetCongestion(ROOT, "val", IN_CH), batch_size=BATCH, shuffle=False)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    loss_fn = HotspotLoss(LAM, TAU)

    # 3) train
    best = 1e9
    for ep in range(EPOCHS):
        model.train(); running = 0.0
        for x, y in tr:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss = loss_fn(model(x), y); loss.backward(); opt.step()
            running += loss.item() * x.size(0)
        m = evaluate(model, va)
        msg = " ".join(f"{k}={v:.4f}" for k, v in m.items())
        print(f"epoch {ep+1}/{EPOCHS}  train_loss={running/len(tr.dataset):.4f}  val[{msg}]")
        if m["NRMSE"] < best:
            best = m["NRMSE"]; torch.save(model.state_dict(), SAVE_PATH)

    print(f"\nDone. Best val NRMSE={best:.4f}. Weights saved to {SAVE_PATH}")
    if MODE == "demo":
        print("REMINDER: these numbers are from FAKE data and mean nothing. "
              "Set MODE='real' with CircuitNet to get real results.")


run()


"""
=====================================================================================
 REAL DATA — run these once, in separate Colab cells, BEFORE setting MODE = "real"
=====================================================================================

# (a) download CircuitNet-N14 (14 nm) from Hugging Face
!pip install huggingface_hub
from huggingface_hub import snapshot_download
snapshot_download(repo_id="CircuitNet/CircuitNet", repo_type="dataset",
                  allow_patterns="CircuitNet-N14/*", local_dir="/content/CircuitNet")

# (b) get CircuitNet's own preprocessing scripts
!git clone https://github.com/circuitnet/CircuitNet.git

# (c) decompress the routability features, then build the congestion training set.
#     Confirm the decompressed path on the download page: circuitnet.github.io/intro/download.html
!python CircuitNet/decompress_routability.py
!python CircuitNet/generate_training_set.py --task congestion \
        --data_path /content/CircuitNet/CircuitNet-N14 \
        --save_path /content/cn_congestion

# (d) generate_training_set.py creates a feature/ and a label/ folder under save_path.
#     Set these two paths in the CONFIG block, set MODE="real", and re-run this file:
#         REAL_FEATURE_DIR = "/content/cn_congestion/feature"
#         REAL_LABEL_DIR   = "/content/cn_congestion/label"
#
# If those exact subfolder names differ, just point REAL_FEATURE_DIR / REAL_LABEL_DIR
# at whatever feature/label folders generate_training_set.py actually produced.
=====================================================================================
"""
