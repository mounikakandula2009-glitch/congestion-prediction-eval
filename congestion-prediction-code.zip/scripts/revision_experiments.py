"""
revision_experiments.py  —  evidence for the editor's revision comments
=======================================================================
Generates the three things the editor asked for. None of these numbers can be
invented — this script produces them from your models/data:

  (1) THRESHOLD SENSITIVITY  -> addresses "inconsistent thresholds" and
      "incomplete validation of the metric": re-evaluates each configuration's
      hotspot-region NRMSE at several evaluation thresholds theta.
  (2) MULTI-SEED STATISTICS  -> addresses "insufficient statistical evidence":
      trains each configuration with several random seeds and reports
      mean +/- std, plus a paired comparison on hotspot-NRMSE.
  (3) LEAVE-ONE-DESIGN-OUT   -> addresses "limited generalization testing":
      trains on two designs and tests on the held-out design, per design.

Run in Colab (after session setup: deeproute_c_colab.py + cn_congestion in /content):
    !python revision_experiments.py

Compute note: (2) and (3) are several full trainings each — budget a few hours
on an A100. Set the RUN_* flags to do one part at a time. (1) is fast (eval only)
if converged checkpoints exist.
"""
import os, glob, csv, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader, Subset
try:
    from scipy import stats as _sps
except Exception:
    _sps = None
from skimage.metrics import structural_similarity as ssim

# ------------------------- CONFIG -------------------------
DATA_ROOT   = "/content/cn_congestion"
MODEL_FILE  = "/content/deeproute_c_colab.py"
DRIVE_OUT   = "/content/drive/MyDrive/CircuitNet_ready"      # results + checkpoints
MAX_EPOCHS  = 120
PATIENCE    = 15
LR          = 2e-4
LAM, TAU    = 1.0, 0.6
THETAS      = [0.4, 0.5, 0.6, 0.7]      # evaluation thresholds for the metric
SEEDS       = [0, 1, 2, 3, 4]            # 5 seeds for tighter statistics
DEVICE      = "cuda" if torch.cuda.is_available() else "cpu"

RUN_THRESH          = True
RUN_SEEDS           = True
RUN_GENERALIZATION  = True

CONFIGS = [   # (name, base width, loss kind)
    ("b32_MSE",     32, "mse"),
    ("b48_MSE",     48, "mse"),
    ("b32_hotspot", 32, "hotspot"),
]
# ----------------------------------------------------------

spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)


# ---------- data ----------
class ArrDS(torch.utils.data.Dataset):
    def __init__(self, files):
        self.fs = files
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt

ALL = sorted(glob.glob(f"{DATA_ROOT}/feature/*.npy"))
def design_of(path):  # filename prefix before "__" is the design
    return os.path.basename(path).split("__")[0]


def hot_nrmse(p, t, theta):
    m = t >= theta
    if m.sum() == 0: return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)

@torch.no_grad()
def predict_all(model, loader):
    model.eval(); P, T = [], []
    for x, y in loader:
        p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]):
            P.append(p[b, 0]); T.append(t[b, 0])
    return P, T

def metrics_from(P, T, theta=0.5):
    ov = [np.sqrt(np.mean((p - t) ** 2)) / (t.max() - t.min() + 1e-8) for p, t in zip(P, T)]
    ss = [ssim(p, t, data_range=1.0) for p, t in zip(P, T)]
    ho = [hot_nrmse(p, t, theta) for p, t in zip(P, T)]
    ho = [h for h in ho if not np.isnan(h)]
    return float(np.mean(ov)), float(np.mean(ss)), float(np.mean(ho))

@torch.no_grad()
def val_loss(model, loader, loss_fn):
    model.eval(); tot, n = 0.0, 0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        tot += float(loss_fn(model(x), y)) * x.size(0); n += x.size(0)
    return tot / n

def train(base, kind, trl, val, seed=0):
    torch.manual_seed(seed); np.random.seed(seed)
    m = dc.DeepRouteC(in_ch=3, base=base).to(DEVICE)
    opt = torch.optim.Adam(m.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    loss_fn = (lambda p, t: F.mse_loss(p, t)) if kind == "mse" else dc.HotspotLoss(LAM, TAU)
    best, best_state, bad = 1e9, None, 0
    for ep in range(MAX_EPOCHS):
        m.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss_fn(m(x), y).backward(); opt.step()
        sched.step()
        vl = val_loss(m, val, loss_fn)
        if vl < best - 1e-6:
            best = vl; best_state = {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}; bad = 0
        else:
            bad += 1
            if bad >= PATIENCE: break
    m.load_state_dict(best_state)
    return m

def split_random(seed=0, val_frac=0.2):
    g = np.random.RandomState(seed); idx = np.arange(len(ALL)); g.shuffle(idx)
    nv = int(len(ALL) * val_frac)
    va = [ALL[i] for i in idx[:nv]]; tr = [ALL[i] for i in idx[nv:]]
    return tr, va

def loaders(tr_files, va_files):
    return (DataLoader(ArrDS(tr_files), batch_size=8, shuffle=True),
            DataLoader(ArrDS(va_files), batch_size=8))

def save_csv(name, header, rows):
    os.makedirs(DRIVE_OUT, exist_ok=True) if os.path.isdir("/content/drive/MyDrive") else None
    local = f"/content/{name}"
    with open(local, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    print("  wrote", local)
    if os.path.isdir(DRIVE_OUT):
        import shutil; shutil.copy(local, os.path.join(DRIVE_OUT, name)); print("  copied to Drive")


# ---------- (1) threshold sensitivity ----------
def experiment_threshold():
    print("\n### (1) THRESHOLD SENSITIVITY ###")
    tr, va = split_random(seed=0)
    trl, val = loaders(tr, va)
    rows = []
    for name, base, kind in CONFIGS:
        print("  training", name, "...")
        m = train(base, kind, trl, val, seed=0)
        P, T = predict_all(m, val)
        row = [name] + [round(metrics_from(P, T, th)[2], 4) for th in THETAS]
        rows.append(row)
        print("   hotspot-NRMSE at", THETAS, "=", row[1:])
    save_csv("threshold_sensitivity.csv", ["config"] + [f"theta={t}" for t in THETAS], rows)


# ---------- (2) multi-seed statistics ----------
def experiment_seeds():
    print("\n### (2) MULTI-SEED STATISTICS ###")
    # track hotspot at BOTH thresholds: 0.5 (for context) and 0.6 (the claim)
    per = {name: {"NRMSE": [], "SSIM": [], "Hot05": [], "Hot06": []} for name, _, _ in CONFIGS}
    for seed in SEEDS:
        tr, va = split_random(seed=seed)
        trl, val = loaders(tr, va)
        for name, base, kind in CONFIGS:
            print(f"  seed {seed}  {name} ...")
            m = train(base, kind, trl, val, seed=seed)
            P, T = predict_all(m, val)
            ov = float(np.mean([np.sqrt(np.mean((p - t) ** 2)) / (t.max() - t.min() + 1e-8) for p, t in zip(P, T)]))
            ss = float(np.mean([ssim(p, t, data_range=1.0) for p, t in zip(P, T)]))
            h05 = [hot_nrmse(p, t, 0.5) for p, t in zip(P, T)]; h05 = float(np.mean([h for h in h05 if not np.isnan(h)]))
            h06 = [hot_nrmse(p, t, 0.6) for p, t in zip(P, T)]; h06 = float(np.mean([h for h in h06 if not np.isnan(h)]))
            per[name]["NRMSE"].append(ov); per[name]["SSIM"].append(ss)
            per[name]["Hot05"].append(h05); per[name]["Hot06"].append(h06)
    rows = []
    for name, _, _ in CONFIGS:
        d = per[name]
        rows.append([name,
                     f"{np.mean(d['NRMSE']):.4f}±{np.std(d['NRMSE']):.4f}",
                     f"{np.mean(d['SSIM']):.4f}±{np.std(d['SSIM']):.4f}",
                     f"{np.mean(d['Hot05']):.4f}±{np.std(d['Hot05']):.4f}",
                     f"{np.mean(d['Hot06']):.4f}±{np.std(d['Hot06']):.4f}"])
    save_csv("multiseed_stats.csv",
             ["config", "NRMSE(mean±std)", "SSIM(mean±std)", "Hotspot@0.5(mean±std)", "Hotspot@0.6(mean±std)"], rows)
    # paired t-tests: proposed vs best baseline (b48_MSE) at the CLAIM threshold 0.6, and at 0.5 for context
    if _sps is not None:
        for thr_key in ("Hot06", "Hot05"):
            a = per["b32_hotspot"][thr_key]; b = per["b48_MSE"][thr_key]
            if len(a) == len(b) and len(a) > 1:
                t, pval = _sps.ttest_rel(a, b)
                direction = "proposed LOWER (better)" if np.mean(a) < np.mean(b) else "proposed HIGHER (worse)"
                lbl = "theta=0.6" if thr_key == "Hot06" else "theta=0.5"
                print(f"  paired t-test hotspot @ {lbl} (b32_hotspot vs b48_MSE): "
                      f"t={t:.3f}, p={pval:.4f}  [{direction}]  "
                      f"means {np.mean(a):.4f} vs {np.mean(b):.4f}")
    else:
        print("  (scipy not available; report mean±std only)")


# ---------- (3) leave-one-design-out generalization ----------
def experiment_generalization():
    print("\n### (3) LEAVE-ONE-DESIGN-OUT GENERALIZATION ###")
    designs = sorted(set(design_of(f) for f in ALL))
    print("  designs:", designs)
    rows = []
    for held in designs:
        tr = [f for f in ALL if design_of(f) != held]
        te = [f for f in ALL if design_of(f) == held]
        if not te or not tr: continue
        trl, tel = loaders(tr, te)
        for name, base, kind in CONFIGS:
            print(f"  hold-out {held}  {name} ...")
            m = train(base, kind, trl, tel, seed=0)   # tel used only for early-stop proxy + eval
            P, T = predict_all(m, tel)
            ov, ss, ho = metrics_from(P, T, 0.5)
            rows.append([held, name, round(ov, 4), round(ss, 4), round(ho, 4)])
            print(f"    NRMSE={ov:.4f} SSIM={ss:.4f} Hot={ho:.4f}")
    save_csv("generalization_loso.csv", ["held_out_design", "config", "NRMSE", "SSIM", "HotspotNRMSE"], rows)
    print("  NOTE: with the current imbalance (one design dominates), held-out results on the")
    print("  tiny designs are high-variance; report them honestly as a generalization probe.")


def main():
    print(f"samples {len(ALL)}  device {DEVICE}")
    if RUN_THRESH:         experiment_threshold()
    if RUN_SEEDS:          experiment_seeds()
    if RUN_GENERALIZATION: experiment_generalization()
    print("\nDONE. CSVs in /content (and Drive if mounted). Paste them back to fill the revised tables.")


if __name__ == "__main__":
    main()
