"""
rebuild_table.py  —  regenerate Table I with all rows converged and comparable
==============================================================================
Trains all three configurations from scratch under an IDENTICAL long schedule
(cosine LR + early stopping), so Table I is a fair like-for-like comparison
(not 15-epoch baselines vs a 120-epoch proposed model).

Selection rule (stated in the paper): each model's checkpoint is chosen by
early stopping on ITS OWN validation loss — MSE models on MSE, the hotspot
model on the hotspot-weighted loss — i.e., each model is selected by the
objective it was trained on. All three metrics are then reported at that
checkpoint.

Run in Colab (after the session-setup: model file + data in /content):
    !python rebuild_table.py

Honest note: this produces the numbers; they exist only after you run it.
Do NOT mix these converged rows with older 15-epoch numbers.
"""
import os, glob, csv, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
from skimage.metrics import structural_similarity as ssim

# ------------------------- CONFIG -------------------------
DATA_ROOT   = "/content/cn_congestion"
MODEL_FILE  = "/content/deeproute_c_colab.py"
MAX_EPOCHS  = 120
PATIENCE    = 15
LR          = 2e-4
LAM, TAU    = 1.0, 0.6
HOT_THRESH  = 0.5
OUT_CSV     = "/content/table1_converged.csv"
CKPT_DIR    = "/content/drive/MyDrive/CircuitNet_ready"   # best checkpoints saved here if it exists
DEVICE      = "cuda" if torch.cuda.is_available() else "cpu"

CONFIGS = [
    ("Backbone b=32, MSE (baseline)",       32, "mse"),
    ("Backbone b=48, MSE",                  48, "mse"),
    ("Backbone b=32, hotspot (proposed)",   32, "hotspot"),
]
# ----------------------------------------------------------

spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)


class FlatDS(torch.utils.data.Dataset):
    def __init__(self, root):
        self.fs = sorted(glob.glob(f"{root}/feature/*.npy"))
        if not self.fs:
            raise FileNotFoundError(f"no features in {root}/feature — restore cn_congestion first")
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt


def hot_nrmse(p, t):
    m = t >= HOT_THRESH
    if m.sum() == 0: return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)


@torch.no_grad()
def eval_metrics(model, loader):
    model.eval(); ov, ss, ho = [], [], []
    for x, y in loader:
        p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]):
            pb, tb = p[b, 0], t[b, 0]
            ov.append(np.sqrt(np.mean((pb - tb) ** 2)) / (tb.max() - tb.min() + 1e-8))
            ss.append(ssim(pb, tb, data_range=1.0))
            h = hot_nrmse(pb, tb)
            if not np.isnan(h): ho.append(h)
    return float(np.mean(ov)), float(np.mean(ss)), float(np.mean(ho))


@torch.no_grad()
def val_loss(model, loader, loss_fn):
    model.eval(); tot, n = 0.0, 0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        tot += float(loss_fn(model(x), y)) * x.size(0); n += x.size(0)
    return tot / n


def train_config(name, base, kind, trl, val):
    print(f"\n=== training {name} ===")
    model = dc.DeepRouteC(in_ch=3, base=base).to(DEVICE)
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    loss_fn = (lambda p, t: F.mse_loss(p, t)) if kind == "mse" else dc.HotspotLoss(LAM, TAU)

    best_vl = 1e9
    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    best_metrics = eval_metrics(model, val)
    bad = 0
    for ep in range(MAX_EPOCHS):
        model.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss_fn(model(x), y).backward(); opt.step()
        sched.step()
        vl = val_loss(model, val, loss_fn)                 # select on own validation loss
        if vl < best_vl - 1e-6:
            best_vl = vl
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            best_metrics = eval_metrics(model, val); bad = 0; tag = "  <- best"
        else:
            bad += 1; tag = ""
        if (ep + 1) % 5 == 0 or tag:
            nr, sm, ho = best_metrics
            print(f"  ep {ep+1:3d}  val_loss={vl:.5f}  (best NRMSE={nr:.4f} SSIM={sm:.4f} Hot={ho:.4f}){tag}")
        if bad >= PATIENCE:
            print(f"  early stop at epoch {ep+1}"); break

    if os.path.isdir(CKPT_DIR):
        fn = os.path.join(CKPT_DIR, "conv_" + name.split(",")[0].replace(" ", "").replace("=", "") + ".pt")
        torch.save(best_state, fn); print(f"  saved {fn}")
    return best_metrics


def main():
    ds = FlatDS(DATA_ROOT)
    nv = int(len(ds) * 0.2)
    tr, va = random_split(ds, [len(ds) - nv, nv], generator=torch.Generator().manual_seed(0))
    trl = DataLoader(tr, batch_size=8, shuffle=True)
    val = DataLoader(va, batch_size=8)
    print(f"train {len(tr)}  val {len(va)}  device {DEVICE}  (max {MAX_EPOCHS} epochs, patience {PATIENCE})")

    rows = []
    for name, base, kind in CONFIGS:
        nr, sm, ho = train_config(name, base, kind, trl, val)
        rows.append((name, nr, sm, ho))

    with open(OUT_CSV, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["Configuration", "NRMSE", "SSIM", "HotspotNRMSE"])
        for r in rows: w.writerow(r)

    print("\n================= TABLE I (converged, comparable) =================")
    print(f"{'Configuration':38s}{'NRMSE ↓':>10s}{'SSIM ↑':>9s}{'Hotspot-NRMSE ↓':>17s}")
    for name, nr, sm, ho in rows:
        print(f"{name:38s}{nr:>10.4f}{sm:>9.4f}{ho:>17.4f}")
    print(f"\nsaved {OUT_CSV}")
    print("All three rows trained under identical schedule; each selected on its own validation loss.")


if __name__ == "__main__":
    main()
