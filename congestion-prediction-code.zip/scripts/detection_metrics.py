"""
detection_metrics.py  —  Major 4 (one-sided metric; false positives)
====================================================================
The hotspot-region NRMSE penalises only missed true hotspots and is blind to
false hotspots (over-prediction). This script adds the complementary measures
the reviewer asked for, on the held-out test set of the primary design:

  (a) error over PREDICTED hotspots (Ŷ ≥ θ)  — sensitive to false positives;
      and error on NON-hotspot tiles (Y < θ);
  (b) detection metrics per θ: precision, recall, F1, ROC-AUC, PR-AUC
      (ground-truth label = tile with Y ≥ θ; score = predicted value Ŷ);
  (c) the fraction of tiles that are hotspots and the fraction of samples with a
      non-empty hotspot set at each θ (empty-hotspot samples are skipped for
      per-sample metrics).

Run:  !python detection_metrics.py
Needs deeproute_c_colab.py + cn_congestion in /content. Trains the full 2x2
factorial on a 70/15/15 split (primary design) and reports on the TEST set.

HONEST NOTE: if the hotspot models are over-predicting (as the low SSIM and the
generalisation collapse suggest), expect HIGH recall but LOW precision and high
error over predicted hotspots. Report whatever comes out.
"""
import os, glob, csv, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score, average_precision_score

# ------------------------- CONFIG -------------------------
DATA_ROOT  = "/content/cn_congestion"
MODEL_FILE = "/content/deeproute_c_colab.py"
DRIVE_OUT  = "/content/drive/MyDrive/CircuitNet_ready"
TRAIN_DESIGN = "RISCY-FPU"             # primary design for the within-design test
MAX_EPOCHS = 120
PATIENCE   = 15
LR         = 2e-4
LAM, TAU   = 1.0, 0.6
THETAS     = [0.4, 0.5, 0.6, 0.7]
SEED       = 0
SPLIT      = (0.70, 0.15, 0.15)
AUC_TILES  = 8192                      # tiles subsampled per map for AUC (speed)
DEVICE     = "cuda" if torch.cuda.is_available() else "cpu"

CONFIGS = [("b32_MSE",32,"mse"),("b48_MSE",48,"mse"),
           ("b32_hotspot",32,"hotspot"),("b48_hotspot",48,"hotspot")]
# ----------------------------------------------------------

spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)

ALL = sorted(glob.glob(f"{DATA_ROOT}/feature/*.npy"))
def design_of(p): return os.path.basename(p).split("__")[0]
PRIM = [f for f in ALL if design_of(f) == TRAIN_DESIGN] or ALL


class ArrDS(torch.utils.data.Dataset):
    def __init__(self, files): self.fs = files
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256,256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256,256), mode="bilinear", align_corners=False)[0]
        return xt, yt

def loader(f, sh=False): return DataLoader(ArrDS(f), batch_size=8, shuffle=sh)

@torch.no_grad()
def predict_all(m, ld):
    m.eval(); P, T = [], []
    for x, y in ld:
        p = m(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]): P.append(p[b,0]); T.append(t[b,0])
    return P, T

@torch.no_grad()
def val_loss(m, ld, fn):
    m.eval(); tot, n = 0.0, 0
    for x, y in ld:
        x, y = x.to(DEVICE), y.to(DEVICE)
        tot += float(fn(m(x), y))*x.size(0); n += x.size(0)
    return tot/n

def train(base, kind, trl, val):
    torch.manual_seed(SEED); np.random.seed(SEED)
    m = dc.DeepRouteC(in_ch=3, base=base).to(DEVICE)
    opt = torch.optim.Adam(m.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    fn = (lambda p,t: F.mse_loss(p,t)) if kind=="mse" else dc.HotspotLoss(LAM,TAU)
    best, best_state, bad = 1e9, None, 0
    for ep in range(MAX_EPOCHS):
        m.train()
        for x,y in trl:
            x,y=x.to(DEVICE),y.to(DEVICE); opt.zero_grad(); fn(m(x),y).backward(); opt.step()
        sched.step(); vl=val_loss(m,val,fn)
        if vl<best-1e-6: best=vl; best_state={k:v.detach().cpu().clone() for k,v in m.state_dict().items()}; bad=0
        else:
            bad+=1
            if bad>=PATIENCE: break
    m.load_state_dict(best_state); return m

def rng(a): return a.max()-a.min()+1e-8

def detection(P, T, th):
    """pooled precision/recall/F1 + per-sample AUCs + complementary errors."""
    TP=FP=FN=0; aucs=[]; prs=[]
    nonhot_num=nonhot_den=predhot_num=predhot_den=0.0
    frac_tiles=[]; nonempty=0
    for p, t in zip(P, T):
        gt = (t >= th); pr = (p >= th)
        TP += int(np.sum(gt & pr)); FP += int(np.sum(~gt & pr)); FN += int(np.sum(gt & ~pr))
        frac_tiles.append(float(gt.mean()))
        if gt.any(): nonempty += 1
        # complementary errors
        if (~gt).any():
            nonhot_num += np.sum((p[~gt]-t[~gt])**2); nonhot_den += (~gt).sum()
        if pr.any():
            predhot_num += np.sum((p[pr]-t[pr])**2); predhot_den += pr.sum()
        # per-sample AUC (needs both classes); subsample tiles for speed
        gf = gt.ravel(); sf = p.ravel()
        if gf.any() and (~gf).any():
            if gf.size > AUC_TILES:
                idx = np.random.RandomState(0).choice(gf.size, AUC_TILES, replace=False)
                gf2, sf2 = gf[idx], sf[idx]
                if gf2.any() and (~gf2).any():
                    aucs.append(roc_auc_score(gf2, sf2)); prs.append(average_precision_score(gf2, sf2))
            else:
                aucs.append(roc_auc_score(gf, sf)); prs.append(average_precision_score(gf, sf))
    prec = TP/(TP+FP) if TP+FP else float('nan')
    rec  = TP/(TP+FN) if TP+FN else float('nan')
    f1   = 2*prec*rec/(prec+rec) if prec+rec else float('nan')
    nonhot_nrmse = (np.sqrt(nonhot_num/nonhot_den) if nonhot_den else float('nan'))
    predhot_nrmse = (np.sqrt(predhot_num/predhot_den) if predhot_den else float('nan'))
    return dict(precision=prec, recall=rec, f1=f1,
                roc_auc=float(np.mean(aucs)) if aucs else float('nan'),
                pr_auc=float(np.mean(prs)) if prs else float('nan'),
                nonhot_nrmse=nonhot_nrmse, predhot_nrmse=predhot_nrmse,
                hot_tile_frac=float(np.mean(frac_tiles)),
                sample_coverage=nonempty/len(T))

def main():
    g=np.random.RandomState(SEED); idx=np.arange(len(PRIM)); g.shuffle(idx)
    n=len(PRIM); ntr=int(n*SPLIT[0]); nva=int(n*SPLIT[1])
    tr=[PRIM[i] for i in idx[:ntr]]; va=[PRIM[i] for i in idx[ntr:ntr+nva]]; te=[PRIM[i] for i in idx[ntr+nva:]]
    trl,val,tel=loader(tr,True),loader(va),loader(te)
    print(f"primary {TRAIN_DESIGN}: train {len(tr)} val {len(va)} test {len(te)}")

    # coverage stats (same for all configs) — print once
    _,Tt=predict_all(dc.DeepRouteC(in_ch=3,base=32).to(DEVICE), tel)  # dummy preds, only T used
    for th in THETAS:
        fr=np.mean([(t>=th).mean() for t in Tt]); cov=np.mean([(t>=th).any() for t in Tt])
        print(f"  theta={th}: hotspot tiles={fr*100:.2f}% of map, samples with hotspots={cov*100:.1f}%")

    header=["config","theta","precision","recall","f1","roc_auc","pr_auc",
            "nonhotspot_nrmse","predicted_hotspot_nrmse"]
    rows=[]
    for name,base,kind in CONFIGS:
        print("training",name,"...")
        m=train(base,kind,trl,val)
        P,T=predict_all(m,tel)
        for th in THETAS:
            dmet=detection(P,T,th)
            rows.append([name,th,round(dmet['precision'],4),round(dmet['recall'],4),round(dmet['f1'],4),
                         round(dmet['roc_auc'],4),round(dmet['pr_auc'],4),
                         round(dmet['nonhot_nrmse'],4),round(dmet['predhot_nrmse'],4)])
            print(f"  {name} θ={th}: P={dmet['precision']:.3f} R={dmet['recall']:.3f} F1={dmet['f1']:.3f} "
                  f"ROC-AUC={dmet['roc_auc']:.3f} PR-AUC={dmet['pr_auc']:.3f} "
                  f"nonhotNRMSE={dmet['nonhot_nrmse']:.3f} predhotNRMSE={dmet['predhot_nrmse']:.3f}")

    local="/content/detection_metrics.csv"
    with open(local,"w",newline="") as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)
    if os.path.isdir(DRIVE_OUT):
        import shutil; shutil.copy(local, os.path.join(DRIVE_OUT,"detection_metrics.csv"))
    print(f"\nsaved {local}")
    print("Read: low precision + high recall + high predicted-hotspot NRMSE = over-prediction "
          "(false hotspots), confirming the one-sided-metric concern (Major 4).")


if __name__ == "__main__":
    main()
