"""
generalization_experiment.py  —  Major 2 (cross-design generalization)
======================================================================
Answers the reviewer's gating comment: train on the primary design and test on
UNSEEN designs, so the result measures generalisation rather than within-design
interpolation.

Protocol (per the reviewer's "train on RISCY-FPU, test on Vortex-small and
nvdla-small"):
  * Train on RISCY-FPU only. A validation split of RISCY-FPU (for early stopping
    and selection) is held out — the TEST designs are never used for selection,
    so there is no selection-on-test bias.
  * Evaluate each trained model separately on each unseen design, and on the
    combined unseen set. Report per-design NRMSE, SSIM, and hotspot-NRMSE at
    theta in {0.4,0.5,0.6,0.7}.
  * Run the full 2x2 factorial {b=32,b=48} x {MSE,hotspot}, multi-seed.

Needs the FULL dataset (3,648 = RISCY-FPU + Vortex-small + nvdla-small) in
/content/cn_congestion. If only 3,456 are present, re-add the two small designs
first (see the instructions printed when a test design is missing).

Run:  !python generalization_experiment.py

HONEST NOTE: the unseen designs have only 96 samples each, so these numbers are
expected to be high-variance and probably worse than the within-design results.
Report them as a generalisation probe, not as polished benchmarks — whatever
they show.
"""
import os, glob, csv, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader
from skimage.metrics import structural_similarity as ssim

# ------------------------- CONFIG -------------------------
DATA_ROOT    = "/content/cn_congestion"
MODEL_FILE   = "/content/deeproute_c_colab.py"
DRIVE_OUT    = "/content/drive/MyDrive/CircuitNet_ready"
TRAIN_DESIGN = "RISCY-FPU"
TEST_DESIGNS = ["Vortex-small", "nvdla-small"]
MAX_EPOCHS   = 120
PATIENCE     = 15
LR           = 2e-4
LAM, TAU     = 1.0, 0.6
THETAS       = [0.4, 0.5, 0.6, 0.7]
SEEDS        = [0, 1, 2]                # set [0] for a fast single-run first
VAL_FRAC     = 0.15                     # RISCY-FPU held out for early stopping
DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"

CONFIGS = [("b32_MSE",32,"mse"),("b48_MSE",48,"mse"),
           ("b32_hotspot",32,"hotspot"),("b48_hotspot",48,"hotspot")]
# ----------------------------------------------------------

spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)

ALL = sorted(glob.glob(f"{DATA_ROOT}/feature/*.npy"))
def design_of(p): return os.path.basename(p).split("__")[0]
def files_of(design): return [f for f in ALL if design_of(f) == design]


class ArrDS(torch.utils.data.Dataset):
    def __init__(self, files): self.fs = files
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt

def loader(files, shuffle=False):
    return DataLoader(ArrDS(files), batch_size=8, shuffle=shuffle)

def hot_nrmse(p, t, th):
    m = t >= th
    if m.sum() == 0: return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)

@torch.no_grad()
def predict_all(model, ld):
    model.eval(); P, T = [], []
    for x, y in ld:
        p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]): P.append(p[b, 0]); T.append(t[b, 0])
    return P, T

def metrics(P, T):
    ov = float(np.mean([np.sqrt(np.mean((p - t) ** 2)) / (t.max() - t.min() + 1e-8) for p, t in zip(P, T)]))
    ss = float(np.mean([ssim(p, t, data_range=1.0) for p, t in zip(P, T)]))
    hot = {}
    for th in THETAS:
        hs = [hot_nrmse(p, t, th) for p, t in zip(P, T)]; hs = [h for h in hs if not np.isnan(h)]
        hot[th] = float(np.mean(hs)) if hs else float("nan")
    return ov, ss, hot

@torch.no_grad()
def val_loss(model, ld, loss_fn):
    model.eval(); tot, n = 0.0, 0
    for x, y in ld:
        x, y = x.to(DEVICE), y.to(DEVICE)
        tot += float(loss_fn(model(x), y)) * x.size(0); n += x.size(0)
    return tot / n

def train(base, kind, trl, val, seed):
    torch.manual_seed(seed); np.random.seed(seed)
    m = dc.DeepRouteC(in_ch=3, base=base).to(DEVICE)
    opt = torch.optim.Adam(m.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    loss_fn = (lambda p, t: F.mse_loss(p, t)) if kind == "mse" else dc.HotspotLoss(LAM, TAU)
    best, best_state, bad = 1e9, None, 0
    for ep in range(MAX_EPOCHS):
        m.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss_fn(m(x), y).backward(); opt.step()
        sched.step()
        vl = val_loss(m, val, loss_fn)
        if vl < best - 1e-6:
            best = vl; best_state = {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}; bad = 0
        else:
            bad += 1
            if bad >= PATIENCE: break
    m.load_state_dict(best_state)
    return m


def main():
    print(f"samples {len(ALL)}  device {DEVICE}  train={TRAIN_DESIGN}  test={TEST_DESIGNS}  seeds {SEEDS}")
    tr_all = files_of(TRAIN_DESIGN)
    if not tr_all:
        raise SystemExit(f"No {TRAIN_DESIGN} samples found.")
    missing = [dz for dz in TEST_DESIGNS if not files_of(dz)]
    if missing:
        raise SystemExit(
            f"Test design(s) missing: {missing}. The dataset in /content is incomplete "
            f"(only {sorted(set(design_of(f) for f in ALL))}). Re-add the two small designs "
            "and re-zip to Drive, then re-run.")

    test_loaders = {dz: loader(files_of(dz)) for dz in TEST_DESIGNS}
    test_loaders["unseen_combined"] = loader([f for dz in TEST_DESIGNS for f in files_of(dz)])

    # accumulate per (config, test_design) across seeds
    acc = {(name, dz): {"NRMSE": [], "SSIM": [], **{f"H{th}": [] for th in THETAS}}
           for name, _, _ in CONFIGS for dz in list(test_loaders)}

    for seed in SEEDS:
        g = np.random.RandomState(seed); idx = np.arange(len(tr_all)); g.shuffle(idx)
        nv = int(len(tr_all) * VAL_FRAC)
        va = [tr_all[i] for i in idx[:nv]]; tr = [tr_all[i] for i in idx[nv:]]
        trl, val = loader(tr, True), loader(va)
        print(f"\nseed {seed}: train {len(tr)} ({TRAIN_DESIGN})  val {len(va)}")
        for name, base, kind in CONFIGS:
            m = train(base, kind, trl, val, seed)
            line = f"  {name:12s}"
            for dz, ld in test_loaders.items():
                P, T = predict_all(m, ld); ov, ss, hot = metrics(P, T)
                a = acc[(name, dz)]
                a["NRMSE"].append(ov); a["SSIM"].append(ss)
                for th in THETAS: a[f"H{th}"].append(hot[th])
                if dz in TEST_DESIGNS:
                    line += f"  [{dz}] Hot@0.6={hot[0.6]:.3f}"
            print(line)

    def ms(v):
        v=[x for x in v if not np.isnan(x)]
        return f"{np.mean(v):.4f}±{np.std(v):.4f}" if v else "n/a"
    header = ["config","test_design","NRMSE","SSIM"]+[f"Hot@{th}" for th in THETAS]
    rows=[]
    for name,_,_ in CONFIGS:
        for dz in list(test_loaders):
            a=acc[(name,dz)]
            rows.append([name,dz,ms(a["NRMSE"]),ms(a["SSIM"])]+[ms(a[f"H{th}"]) for th in THETAS])

    local="/content/generalization_results.csv"
    with open(local,"w",newline="") as f:
        w=csv.writer(f); w.writerow(header); w.writerows(rows)
    if os.path.isdir(DRIVE_OUT):
        import shutil; shutil.copy(local, os.path.join(DRIVE_OUT,"generalization_results.csv"))

    print("\n=========== CROSS-DESIGN GENERALIZATION (train on RISCY-FPU) ===========")
    print(" | ".join(header))
    for r in rows: print(" | ".join(str(x) for x in r))
    print(f"\nsaved {local}")
    print("Report per-design (Major 2b). Expect high variance on the 96-sample designs; "
          "state this as a generalisation probe.")


if __name__ == "__main__":
    main()
