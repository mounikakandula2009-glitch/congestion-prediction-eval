"""
test_split_experiment.py  —  Major 1 (independent test set) + Major 3 (full factorial)
======================================================================================
Addresses the reviewer's two gating comments at once:

  * 70/15/15 TRAIN / VALIDATION / TEST split. Early stopping and checkpoint
    selection use VALIDATION only; every reported metric is on the UNTOUCHED
    TEST set (removes the selection-on-evaluation-data bias, Major 1).
  * Full 2x2 factorial: {b=32, b=48} x {MSE, hotspot} — the previously missing
    b=48 hotspot cell is included, so objective and capacity are no longer
    confounded (Major 3).
  * Reports hotspot-NRMSE at theta in {0.4,0.5,0.6,0.7}, parameter counts,
    mean stopping epoch, and multi-seed mean +/- std on the test set, with
    paired t-tests at theta=0.6 and 0.5.

Run in Colab (after session setup: deeproute_c_colab.py + cn_congestion in /content):
    !python test_split_experiment.py

HONEST NOTES
  * A random sample-level split still places placement variants of the SAME
    design in train and test; this experiment fixes the selection-bias problem
    (Major 1) but NOT cross-design generalization (Major 2) — that is the
    separate leave-one-design-out run.
  * These are real trainings; the numbers exist only after you run it. The
    test-set numbers may be worse than the earlier validation-set numbers —
    report whatever comes out.

Compute: 4 configs x N seeds full trainings. Default 3 seeds = 12 trainings,
a few hours on an A100. Set SEEDS=[0] for a quick single-run test-set table first.
"""
import os, glob, csv, time, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader
try:
    from scipy import stats as _sps
except Exception:
    _sps = None
from skimage.metrics import structural_similarity as ssim

# ------------------------- CONFIG -------------------------
DATA_ROOT  = "/content/cn_congestion"
MODEL_FILE = "/content/deeproute_c_colab.py"
DRIVE_OUT  = "/content/drive/MyDrive/CircuitNet_ready"
MAX_EPOCHS = 120
PATIENCE   = 15
LR         = 2e-4
LAM, TAU   = 1.0, 0.6
THETAS     = [0.4, 0.5, 0.6, 0.7]
SEEDS      = [0, 1, 2]                 # set [0] for a fast single-run test-set table
SPLIT      = (0.70, 0.15, 0.15)        # train / val / test
DEVICE     = "cuda" if torch.cuda.is_available() else "cpu"

CONFIGS = [   # full 2x2 factorial
    ("b32_MSE",     32, "mse"),
    ("b48_MSE",     48, "mse"),
    ("b32_hotspot", 32, "hotspot"),
    ("b48_hotspot", 48, "hotspot"),   # <-- the missing cell (Major 3)
]
# ----------------------------------------------------------

spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)

ALL = sorted(glob.glob(f"{DATA_ROOT}/feature/*.npy"))


class ArrDS(torch.utils.data.Dataset):
    def __init__(self, files): self.fs = files
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt


def split_tvt(seed):
    g = np.random.RandomState(seed); idx = np.arange(len(ALL)); g.shuffle(idx)
    n = len(ALL); ntr = int(n * SPLIT[0]); nva = int(n * SPLIT[1])
    tr = [ALL[i] for i in idx[:ntr]]
    va = [ALL[i] for i in idx[ntr:ntr + nva]]
    te = [ALL[i] for i in idx[ntr + nva:]]
    return tr, va, te


def loader(files, shuffle=False):
    return DataLoader(ArrDS(files), batch_size=8, shuffle=shuffle)


def hot_nrmse(p, t, th):
    m = t >= th
    if m.sum() == 0: return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)


@torch.no_grad()
def predict_all(model, ld):
    model.eval(); P, T = [], []
    for x, y in ld:
        p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]):
            P.append(p[b, 0]); T.append(t[b, 0])
    return P, T


def metrics(P, T):
    ov = float(np.mean([np.sqrt(np.mean((p - t) ** 2)) / (t.max() - t.min() + 1e-8) for p, t in zip(P, T)]))
    ss = float(np.mean([ssim(p, t, data_range=1.0) for p, t in zip(P, T)]))
    hot = {}
    for th in THETAS:
        hs = [hot_nrmse(p, t, th) for p, t in zip(P, T)]; hs = [h for h in hs if not np.isnan(h)]
        hot[th] = float(np.mean(hs))
    return ov, ss, hot


@torch.no_grad()
def val_loss(model, ld, loss_fn):
    model.eval(); tot, n = 0.0, 0
    for x, y in ld:
        x, y = x.to(DEVICE), y.to(DEVICE)
        tot += float(loss_fn(model(x), y)) * x.size(0); n += x.size(0)
    return tot / n


def train(base, kind, trl, val, seed):
    torch.manual_seed(seed); np.random.seed(seed)
    m = dc.DeepRouteC(in_ch=3, base=base).to(DEVICE)
    opt = torch.optim.Adam(m.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    loss_fn = (lambda p, t: F.mse_loss(p, t)) if kind == "mse" else dc.HotspotLoss(LAM, TAU)
    best, best_state, bad, stop_ep = 1e9, None, 0, MAX_EPOCHS
    for ep in range(MAX_EPOCHS):
        m.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss_fn(m(x), y).backward(); opt.step()
        sched.step()
        vl = val_loss(m, val, loss_fn)
        if vl < best - 1e-6:
            best = vl; best_state = {k: v.detach().cpu().clone() for k, v in m.state_dict().items()}
            bad = 0; stop_ep = ep + 1
        else:
            bad += 1
            if bad >= PATIENCE: break
    m.load_state_dict(best_state)
    params = sum(p.numel() for p in m.parameters())
    return m, stop_ep, params


def main():
    print(f"samples {len(ALL)}  device {DEVICE}  split {SPLIT}  seeds {SEEDS}")
    # accumulate test-set metrics across seeds
    acc = {name: {"NRMSE": [], "SSIM": [], "ep": [], "params": 0,
                  **{f"H{th}": [] for th in THETAS}} for name, _, _ in CONFIGS}
    for seed in SEEDS:
        tr, va, te = split_tvt(seed)
        print(f"\nseed {seed}: train {len(tr)}  val {len(va)}  test {len(te)}")
        trl, val, tel = loader(tr, True), loader(va), loader(te)
        for name, base, kind in CONFIGS:
            t0 = time.time()
            m, stop_ep, params = train(base, kind, trl, val, seed)
            P, T = predict_all(m, tel)                 # TEST set only
            ov, ss, hot = metrics(P, T)
            acc[name]["NRMSE"].append(ov); acc[name]["SSIM"].append(ss)
            acc[name]["ep"].append(stop_ep); acc[name]["params"] = params
            for th in THETAS: acc[name][f"H{th}"].append(hot[th])
            print(f"  {name:12s} test NRMSE={ov:.4f} SSIM={ss:.4f} "
                  f"Hot@0.6={hot[0.6]:.4f}  stop_ep={stop_ep}  {params/1e6:.2f}M  {time.time()-t0:.0f}s")

    def ms(v): return f"{np.mean(v):.4f}±{np.std(v):.4f}"
    header = ["config", "params(M)", "stop_epoch(mean)", "NRMSE", "SSIM"] + [f"Hot@{th}" for th in THETAS]
    rows = []
    for name, _, _ in CONFIGS:
        a = acc[name]
        rows.append([name, f"{a['params']/1e6:.2f}", f"{np.mean(a['ep']):.0f}",
                     ms(a["NRMSE"]), ms(a["SSIM"])] + [ms(a[f"H{th}"]) for th in THETAS])
    # save
    os.makedirs(DRIVE_OUT, exist_ok=True) if os.path.isdir("/content/drive/MyDrive") else None
    local = "/content/test_split_results.csv"
    with open(local, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    if os.path.isdir(DRIVE_OUT):
        import shutil; shutil.copy(local, os.path.join(DRIVE_OUT, "test_split_results.csv"))
    print("\n================= TEST-SET RESULTS (full factorial) =================")
    print(" | ".join(header))
    for r in rows: print(" | ".join(str(x) for x in r))
    print(f"\nsaved {local}")

    # paired t-tests on the TEST set: proposed (b32_hotspot) vs strongest baseline (b48_MSE)
    if _sps is not None and len(SEEDS) > 1:
        for th in (0.6, 0.5):
            a = acc["b32_hotspot"][f"H{th}"]; b = acc["b48_MSE"][f"H{th}"]
            t, pv = _sps.ttest_rel(a, b)
            d = "proposed LOWER (better)" if np.mean(a) < np.mean(b) else "proposed HIGHER (worse)"
            print(f"  paired t-test @ theta={th} (b32_hotspot vs b48_MSE): "
                  f"t={t:.3f}, df={len(a)-1}, p={pv:.4f}  [{d}]  means {np.mean(a):.4f} vs {np.mean(b):.4f}")
    print("\nNote: results are on the held-out TEST set (Major 1); all four factorial "
          "cells are included (Major 3). FLOPs/inference-time can be added with a profiler if required.")


if __name__ == "__main__":
    main()
