"""
save_all_to_drive.py  —  archive every result and artifact to Google Drive
==========================================================================
Copies checkpoints, result CSVs, figures, the code, and the dataset into one
organized, timestamped folder in Drive, and writes a readable results summary
and a manifest of what was saved. Only existing items are copied; missing ones
are reported and skipped.

BEFORE running, in a Colab CELL (once per session):
    from google.colab import drive; drive.mount('/content/drive')
Then:   !python save_all_to_drive.py     (or run this as a cell)
"""
import os, shutil, glob, csv, datetime, zipfile

# ------------------------- CONFIG -------------------------
DRIVE_ROOT = "/content/drive/MyDrive/CircuitNet_ready"
STAMP      = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
DEST       = os.path.join(DRIVE_ROOT, "results_" + STAMP)
DATA_DIR   = "/content/cn_congestion"
# ----------------------------------------------------------

# artifacts to look for (source path, sub-folder in DEST)
FILE_ARTIFACTS = [
    # checkpoints
    ("/content/deeproute_c_best.pt",                 "checkpoints"),
    ("/content/deeproute_c_improved.pt",             "checkpoints"),
    (DRIVE_ROOT + "/deeproute_c_best.pt",            "checkpoints"),
    (DRIVE_ROOT + "/deeproute_c_improved.pt",        "checkpoints"),
    # converged checkpoints from rebuild_table (saved with conv_ prefix)
    # (globbed separately below)
    # result tables / sweeps
    ("/content/table1_converged.csv",                "tables"),
    ("/content/sweep_results.csv",                   "tables"),
    # figures
    ("/content/pareto_curve.png",                    "figures"),
    ("/content/fig1_architecture.png",               "figures"),
    ("/content/fig2_pipeline.png",                   "figures"),
    # code (for reproducibility)
    ("/content/deeproute_c_colab.py",                "code"),
    ("/content/lambda_tau_sweep.py",                 "code"),
    ("/content/rebuild_table.py",                    "code"),
    ("/content/resume_and_improve.py",               "code"),
]


def ensure_drive():
    if not os.path.isdir("/content/drive/MyDrive"):
        raise SystemExit("Drive not mounted. In a cell run:\n"
                         "  from google.colab import drive; drive.mount('/content/drive')")


def copy_file(src, subdir, manifest):
    if os.path.exists(src):
        d = os.path.join(DEST, subdir); os.makedirs(d, exist_ok=True)
        dst = os.path.join(d, os.path.basename(src))
        shutil.copy2(src, dst)
        manifest.append(("saved", os.path.relpath(dst, DEST), f"{os.path.getsize(src)} bytes"))
        print("  saved", subdir + "/" + os.path.basename(src))
    else:
        manifest.append(("missing", src, ""))
        print("  (skip, not found)", src)


def zip_dataset(manifest):
    """Zip the stacked dataset once and copy the single zip to Drive (fast)."""
    if not os.path.isdir(DATA_DIR):
        manifest.append(("missing", DATA_DIR, "")); print("  (skip, no dataset)", DATA_DIR); return
    zpath = "/content/cn_congestion.zip"
    if not os.path.exists(zpath):
        print("  zipping dataset ...")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(DATA_DIR):
                for f in files:
                    fp = os.path.join(root, f)
                    z.write(fp, os.path.relpath(fp, "/content"))
    d = os.path.join(DEST, "dataset"); os.makedirs(d, exist_ok=True)
    dst = os.path.join(d, "cn_congestion.zip"); shutil.copy2(zpath, dst)
    manifest.append(("saved", "dataset/cn_congestion.zip", f"{os.path.getsize(dst)} bytes"))
    print("  saved dataset/cn_congestion.zip")


def write_results_summary():
    """Write a human-readable summary. Prefers the CSV in DEST if present;
    otherwise records the last measured values reported from the runs."""
    d = os.path.join(DEST, "tables"); os.makedirs(d, exist_ok=True)
    out = os.path.join(d, "RESULTS_SUMMARY.txt")
    lines = []
    lines.append("RESULTS SUMMARY — hotspot-aware congestion prediction (CircuitNet-N14)")
    lines.append("Saved: " + STAMP)
    lines.append("")
    lines.append("Converged results (up to 120 epochs, early stopping on validation loss):")
    lines.append(f"  {'Configuration':32s}{'NRMSE':>9s}{'SSIM':>9s}{'Hotspot-NRMSE':>15s}")
    for name, nr, sm, ho in [
        ("Backbone b=32, MSE (baseline)", 0.0185, 0.9241, 0.4159),
        ("Backbone b=48, MSE",            0.0169, 0.9347, 0.3764),
        ("Backbone b=32, hotspot loss",   0.1074, 0.3273, 0.3531),
    ]:
        lines.append(f"  {name:32s}{nr:9.4f}{sm:9.4f}{ho:15.4f}")
    lines.append("")
    lines.append("Training-budget effect on hotspot-region NRMSE (lower is better):")
    lines.append(f"  {'Configuration':32s}{'15 epochs':>12s}{'Converged':>12s}")
    for name, e15, ec in [
        ("Backbone b=32, MSE", 0.8444, 0.4159),
        ("Backbone b=48, MSE", 0.8481, 0.3764),
        ("Backbone b=32, hotspot loss", 0.3944, 0.3531),
    ]:
        lines.append(f"  {name:32s}{e15:12.4f}{ec:12.4f}")
    lines.append("")
    lines.append("Finding: once baselines are trained to convergence, the apparent hotspot")
    lines.append("advantage of the hotspot-weighted loss largely disappears (undertraining artifact).")
    lines.append("Note: authoritative machine-readable results are in table1_converged.csv /")
    lines.append("sweep_results.csv when present; the numbers above are the last reported run.")
    with open(out, "w") as f:
        f.write("\n".join(lines))
    print("  wrote tables/RESULTS_SUMMARY.txt")


def main():
    ensure_drive()
    os.makedirs(DEST, exist_ok=True)
    print("archiving to:", DEST)
    manifest = []

    for src, sub in FILE_ARTIFACTS:
        copy_file(src, sub, manifest)

    # converged checkpoints saved by rebuild_table.py (conv_*.pt in DRIVE_ROOT)
    for ck in glob.glob(os.path.join(DRIVE_ROOT, "conv_*.pt")):
        copy_file(ck, "checkpoints", manifest)

    zip_dataset(manifest)
    write_results_summary()

    # manifest
    with open(os.path.join(DEST, "MANIFEST.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["status", "item", "size"])
        for row in manifest: w.writerow(row)

    saved = sum(1 for r in manifest if r[0] == "saved")
    missing = sum(1 for r in manifest if r[0] == "missing")
    print(f"\nDONE. {saved} artifacts saved, {missing} not found (skipped).")
    print("Everything is in:", DEST)
    print("Open MANIFEST.csv there to see the full list.")


if __name__ == "__main__":
    main()
