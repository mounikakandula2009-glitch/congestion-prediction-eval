"""
lambda_tau_sweep.py  —  SCI paper, Pillar 1
============================================
Sweeps the hotspot-loss weight (lambda) and threshold (tau) on your EXISTING
CircuitNet data, records overall-NRMSE, SSIM, and hotspot-region-NRMSE for each
setting, writes a CSV, and draws the average-vs-hotspot Pareto curve.

Run in Colab:   !python lambda_tau_sweep.py
Needs:          /content/deeproute_c_colab.py  and  /content/cn_congestion/{feature,label}

Honest note: these are real training runs. The numbers this prints are measured.
Use fewer epochs for the sweep (SWEEP_EPOCHS), then re-train the chosen (lambda,tau)
at full epochs for the final table.
"""
import os, glob, csv, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
from skimage.metrics import structural_similarity as ssim
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

# ---------------- CONFIG ----------------
ROOT         = "/content/cn_congestion"
MODEL_FILE   = "/content/deeproute_c_colab.py"
BASE         = 32
SWEEP_EPOCHS = 10                       # fewer epochs for the sweep; raise for final run
HOT_METRIC_THRESH = 0.5                 # threshold for the hotspot-region METRIC (fixed)
LAMBDAS      = [0.0, 0.1, 0.3, 0.5, 1.0, 2.0]   # 0.0 == plain MSE baseline
TAUS         = [0.4, 0.5, 0.6, 0.7]
OUT_CSV      = "/content/sweep_results.csv"
OUT_PNG      = "/content/pareto_curve.png"
DEVICE       = "cuda" if torch.cuda.is_available() else "cpu"
# ----------------------------------------

# import the model / loss definitions from your existing file
spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# disabled"), "dc", "exec"), dc.__dict__)


class FlatDS(torch.utils.data.Dataset):
    def __init__(self, root):
        self.fs = sorted(glob.glob(f"{root}/feature/*.npy"))
        if not self.fs:
            raise FileNotFoundError(f"no features in {root}/feature")
    def __len__(self):
        return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min()
            x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt


def hot_nrmse(p, t):
    m = t >= HOT_METRIC_THRESH
    if m.sum() == 0:
        return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)


def evaluate(model, loader):
    model.eval(); ov, ss, ho = [], [], []
    with torch.no_grad():
        for x, y in loader:
            p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
            for b in range(p.shape[0]):
                pb, tb = p[b, 0], t[b, 0]
                ov.append(np.sqrt(np.mean((pb - tb) ** 2)) / (tb.max() - tb.min() + 1e-8))
                ss.append(ssim(pb, tb, data_range=1.0))
                h = hot_nrmse(pb, tb)
                if not np.isnan(h):
                    ho.append(h)
    return float(np.mean(ov)), float(np.mean(ss)), float(np.mean(ho))


def train_one(lam, tau, trl, val, epochs):
    m = dc.DeepRouteC(in_ch=3, base=BASE).to(DEVICE)
    opt = torch.optim.Adam(m.parameters(), lr=2e-4)
    if lam == 0.0:
        loss_fn = lambda p, t: F.mse_loss(p, t)
    else:
        loss_fn = dc.HotspotLoss(lam, tau)
    for _ in range(epochs):
        m.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad()
            loss_fn(m(x), y).backward()
            opt.step()
    return evaluate(m, val)


def main():
    ds = FlatDS(ROOT)
    nv = int(len(ds) * 0.2)
    tr, va = random_split(ds, [len(ds) - nv, nv], generator=torch.Generator().manual_seed(0))
    trl = DataLoader(tr, batch_size=8, shuffle=True)
    val = DataLoader(va, batch_size=8)
    print(f"train {len(tr)}  val {len(va)}  device {DEVICE}")

    rows = []
    for lam in LAMBDAS:
        taus = [0.0] if lam == 0.0 else TAUS       # tau irrelevant when lambda=0
        for tau in taus:
            tag = "MSE baseline" if lam == 0.0 else f"lam={lam}, tau={tau}"
            print(f"training {tag} ...")
            ov, sm, ho = train_one(lam, tau, trl, val, SWEEP_EPOCHS)
            rows.append({"lambda": lam, "tau": tau, "NRMSE": ov, "SSIM": sm, "HotspotNRMSE": ho})
            print(f"   NRMSE={ov:.4f}  SSIM={sm:.4f}  Hotspot-NRMSE={ho:.4f}")

    # write CSV
    with open(OUT_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["lambda", "tau", "NRMSE", "SSIM", "HotspotNRMSE"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nsaved {OUT_CSV}")

    # print sorted table (best hotspot first)
    print("\n=== SWEEP RESULTS (sorted by Hotspot-NRMSE) ===")
    print(f"{'lambda':>7}{'tau':>6}{'NRMSE':>9}{'SSIM':>8}{'Hotspot':>10}")
    for r in sorted(rows, key=lambda d: d["HotspotNRMSE"]):
        print(f"{r['lambda']:>7}{r['tau']:>6}{r['NRMSE']:>9.4f}{r['SSIM']:>8.4f}{r['HotspotNRMSE']:>10.4f}")

    # Pareto plot: overall NRMSE (x) vs hotspot NRMSE (y); lower-left is better
    plt.figure(figsize=(6, 5))
    for r in rows:
        base = (r["lambda"] == 0.0)
        plt.scatter(r["NRMSE"], r["HotspotNRMSE"],
                    s=90 if base else 60,
                    marker="*" if base else "o",
                    label="MSE baseline" if base else None,
                    zorder=3)
        if not base:
            plt.annotate(f"({r['lambda']},{r['tau']})", (r["NRMSE"], r["HotspotNRMSE"]),
                         fontsize=7, xytext=(3, 3), textcoords="offset points")
    plt.xlabel("Overall NRMSE  (lower better)")
    plt.ylabel("Hotspot-region NRMSE  (lower better)")
    plt.title("Average vs. hotspot accuracy trade-off")
    plt.grid(alpha=0.3); plt.legend()
    plt.tight_layout(); plt.savefig(OUT_PNG, dpi=180)
    print(f"saved {OUT_PNG}")
    print("\nInterpretation: the ideal point is lower-left. Look for a (lambda,tau) that")
    print("sits far below the baseline in Hotspot-NRMSE without moving far right in NRMSE.")


if __name__ == "__main__":
    main()
