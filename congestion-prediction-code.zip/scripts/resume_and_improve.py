"""
resume_and_improve.py  —  continue training from your saved checkpoint
======================================================================
Loads the model you already trained (saved to Google Drive), evaluates it so
you see the starting point, then continues training with a cosine LR schedule
and early stopping to improve NRMSE / SSIM / hotspot-NRMSE, and saves the
improved model back to Drive.

BEFORE running, in a Colab CELL (once per session):
    from google.colab import drive; drive.mount('/content/drive')
and make sure /content/cn_congestion exists (restore the zip from Drive if the
runtime reset). Then:   !python resume_and_improve.py

Honest note: this proposes the experiment; the improved numbers come only from
running it. Warm-starting saves time but does not guarantee a specific gain.
Keep the loss the same as the checkpoint was trained with, or you are changing
what the model optimizes.
"""
import os, glob, importlib.util
import numpy as np, torch, torch.nn.functional as F
from torch.utils.data import DataLoader, random_split
from skimage.metrics import structural_similarity as ssim

# ------------------------- CONFIG -------------------------
DRIVE_CKPT_IN  = "/content/drive/MyDrive/CircuitNet_ready/deeproute_c_best.pt"
DRIVE_CKPT_OUT = "/content/drive/MyDrive/CircuitNet_ready/deeproute_c_improved.pt"
DATA_ROOT      = "/content/cn_congestion"
MODEL_FILE     = "/content/deeproute_c_colab.py"
BASE           = 32
LOSS           = "hotspot"      # "hotspot" or "mse"  (match the checkpoint's objective)
LAM, TAU       = 1.0, 0.6
MAX_EPOCHS     = 120
PATIENCE       = 15             # stop if val NRMSE hasn't improved for this many epochs
LR             = 1e-4          # lower LR for fine-tuning a warm-started model
HOT_THRESH     = 0.5
DEVICE         = "cuda" if torch.cuda.is_available() else "cpu"
# ----------------------------------------------------------

# import model / loss definitions
spec = importlib.util.spec_from_file_location("dc", MODEL_FILE)
dc = importlib.util.module_from_spec(spec)
exec(compile(open(MODEL_FILE).read().replace("\nrun()", "\n# off"), "dc", "exec"), dc.__dict__)


class FlatDS(torch.utils.data.Dataset):
    def __init__(self, root):
        self.fs = sorted(glob.glob(f"{root}/feature/*.npy"))
        if not self.fs:
            raise FileNotFoundError(f"no features in {root}/feature — restore cn_congestion first")
    def __len__(self): return len(self.fs)
    def __getitem__(self, i):
        x = np.load(self.fs[i]).astype("float32")
        y = np.load(self.fs[i].replace("/feature/", "/label/")).astype("float32")
        for c in range(x.shape[0]):
            r = x[c].max() - x[c].min(); x[c] = (x[c] - x[c].min()) / (r + 1e-8)
        y = y / (y.max() + 1e-8)
        xt = F.interpolate(torch.from_numpy(x)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        yt = F.interpolate(torch.from_numpy(y)[None], size=(256, 256), mode="bilinear", align_corners=False)[0]
        return xt, yt


def hot_nrmse(p, t):
    m = t >= HOT_THRESH
    if m.sum() == 0: return np.nan
    return np.sqrt(np.mean((p[m] - t[m]) ** 2)) / (t.max() - t.min() + 1e-8)


@torch.no_grad()
def evaluate(model, loader):
    model.eval(); ov, ss, ho = [], [], []
    for x, y in loader:
        p = model(x.to(DEVICE)).cpu().numpy(); t = y.numpy()
        for b in range(p.shape[0]):
            pb, tb = p[b, 0], t[b, 0]
            ov.append(np.sqrt(np.mean((pb - tb) ** 2)) / (tb.max() - tb.min() + 1e-8))
            ss.append(ssim(pb, tb, data_range=1.0))
            h = hot_nrmse(pb, tb)
            if not np.isnan(h): ho.append(h)
    return float(np.mean(ov)), float(np.mean(ss)), float(np.mean(ho))


def main():
    if not os.path.exists(DRIVE_CKPT_IN):
        raise FileNotFoundError(f"checkpoint not found: {DRIVE_CKPT_IN}\n"
                                "Mount Drive in a cell first: "
                                "from google.colab import drive; drive.mount('/content/drive')")
    # data
    ds = FlatDS(DATA_ROOT)
    nv = int(len(ds) * 0.2)
    tr, va = random_split(ds, [len(ds) - nv, nv], generator=torch.Generator().manual_seed(0))
    trl = DataLoader(tr, batch_size=8, shuffle=True)
    val = DataLoader(va, batch_size=8)
    print(f"train {len(tr)}  val {len(va)}  device {DEVICE}")

    # model + load checkpoint
    model = dc.DeepRouteC(in_ch=3, base=BASE).to(DEVICE)
    state = torch.load(DRIVE_CKPT_IN, map_location=DEVICE)
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        print(f"warning: partial load (missing={len(missing)}, unexpected={len(unexpected)}). "
              "If many, the checkpoint's BASE differs from this BASE.")
    print("loaded checkpoint:", DRIVE_CKPT_IN)

    # BEFORE metrics
    b_nrmse, b_ssim, b_hot = evaluate(model, val)
    print(f"\nSTARTING POINT  NRMSE={b_nrmse:.4f}  SSIM={b_ssim:.4f}  Hotspot-NRMSE={b_hot:.4f}\n")

    # continue training
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=MAX_EPOCHS)
    loss_fn = dc.HotspotLoss(LAM, TAU) if LOSS == "hotspot" else (lambda p, t: F.mse_loss(p, t))

    best_hot = b_hot                       # <-- select on HOTSPOT-NRMSE (the paper's metric)
    best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    best_triple = (b_nrmse, b_ssim, b_hot)
    bad = 0
    for ep in range(MAX_EPOCHS):
        model.train()
        for x, y in trl:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(); loss_fn(model(x), y).backward(); opt.step()
        sched.step()
        nrmse, sm, ho = evaluate(model, val)
        marker = ""
        if ho < best_hot - 1e-4:           # keep the epoch with the LOWEST hotspot error
            best_hot = ho
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            best_triple = (nrmse, sm, ho); bad = 0; marker = "  <- best (hotspot)"
        else:
            bad += 1
        print(f"epoch {ep+1:3d}/{MAX_EPOCHS}  NRMSE={nrmse:.4f}  SSIM={sm:.4f}  Hotspot={ho:.4f}{marker}")
        if bad >= PATIENCE:
            print(f"early stop (no improvement for {PATIENCE} epochs)"); break

    # save best back to Drive
    torch.save(best_state, DRIVE_CKPT_OUT)
    print(f"\nsaved improved model -> {DRIVE_CKPT_OUT}")
    print("=== BEFORE vs AFTER (best) ===")
    print(f"  before : NRMSE={b_nrmse:.4f}  SSIM={b_ssim:.4f}  Hotspot-NRMSE={b_hot:.4f}")
    print(f"  after  : NRMSE={best_triple[0]:.4f}  SSIM={best_triple[1]:.4f}  Hotspot-NRMSE={best_triple[2]:.4f}")


if __name__ == "__main__":
    main()
